package espasa.mario.progressbar_switch_checkbox_radiobutton

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import espasa.mario.progressbar_switch_checkbox_radiobutton.ui.theme.ProgressBar_Switch_CheckBox_RadioButtonTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProgressBar_Switch_CheckBox_RadioButtonTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {

                    DefaultPreview()

                }
            }
        }
    }
}

@Composable
fun ProgressBar(){

    var showLoading by rememberSaveable{ mutableStateOf(false)}
    var progressStatus by rememberSaveable { mutableStateOf(0f) }

    Column(
        Modifier
            .padding(24.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if(showLoading){
            CircularProgressIndicator(
                color = Color.Blue,
                strokeWidth = 3.dp,
                progress = progressStatus
            )
            LinearProgressIndicator(color = Color.Green,
                modifier = Modifier.padding(top = 32.dp),
                backgroundColor = Color.Gray,
                progress = progressStatus
            )

        }

        Row(
            Modifier.fillMaxWidth(),
            Arrangement.SpaceAround,
            Alignment.CenterVertically
        ) {
            Button(onClick = {

                if(progressStatus > 0f){
                    progressStatus -= 0.1f
                }else{
                    progressStatus = 1f
                }

            }
            ) {
                Text(text = "Reducir")
            }
            Button(onClick = {
                if(progressStatus < 1f){
                    progressStatus += 0.1f
                }else{
                    progressStatus =0f
                }

            }
            ) {
                Text(text = "Aumentar")
            }
        }
        
        Button(
            modifier = Modifier.padding(top = 100.dp),
            onClick = {
                showLoading = !showLoading

            }
        ) {
            Text(text = "Activar/Desactivar")
        }
    }


}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ProgressBar_Switch_CheckBox_RadioButtonTheme {
        ProgressBar()
    }
}