package espasa.mario.buttonsandimages

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.SnackbarDefaults.backgroundColor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import espasa.mario.buttonsandimages.ui.theme.ButtonsAndImagesTheme
import org.intellij.lang.annotations.JdkConstants.HorizontalAlignment

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ButtonsAndImagesTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DefaultPreview()
                }
            }
        }
    }
}

val StyleTextBasic = TextStyle(
    color= Color.Cyan,
    fontWeight = FontWeight.ExtraLight,
    fontSize = 25.sp
)

@Composable
fun View(){

    var nombre by rememberSaveable{ mutableStateOf("") }
    var descripcion by rememberSaveable{ mutableStateOf("") }

    var name by rememberSaveable{ mutableStateOf("Mono") }
    var description by rememberSaveable{ mutableStateOf("Hola Mundo") }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row() {
            Box(modifier = Modifier.padding(200.dp,10.dp,0.dp,0.dp)){
                FloatingActionButton(
                    onClick = { /*TODO*/ },
                    backgroundColor = Color.Blue
                )
                {
                    Icon(Icons.Default.Edit, contentDescription = null)
                }
            }
        }
        Row() {
            Image(
                painter = painterResource(id = R.drawable.fondo) ,
                contentDescription = "Fondo",
                modifier = Modifier.size(270.dp)
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            Box(modifier = Modifier.padding(40.dp,0.dp,0.dp,0.dp)){
                Image(
                    painter = painterResource(id = R.drawable.mono),
                    contentDescription = "mono",
                    contentScale = ContentScale.Crop,
                    modifier =
                    Modifier
                        .clip(CircleShape)
                        .size(80.dp)
                )
            }

            Column(modifier = Modifier.padding(5.dp,0.dp,0.dp,0.dp)) {
                Text(text = name)
                Text(text = description)
            }
            
            
        }

        Row() {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                OutlinedTextField(
                    value = nombre,
                    onValueChange = {
                        nombre = it
                    },
                    label = { Text(text = "Introduce nombre")},
                    textStyle = StyleTextBasic,
                    singleLine = true

                )

                OutlinedTextField(value = descripcion,
                    onValueChange = {
                        descripcion = it
                    },
                    label = { Text(text = "Introduce descripcion")},
                    maxLines = 3
                )
                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(210.dp,0.dp,0.dp,0.dp)){
                        Button(
                            onClick = {
                                name = nombre
                                description = descripcion
                            },
                            colors = ButtonDefaults.buttonColors(
                                backgroundColor = Color.Green,
                                contentColor = Color.White
                            )
                        ) {
                            Text(
                                text = "Actualizar"
                            )
                        }
                    }

                }



            }

        }



    }
    


}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ButtonsAndImagesTheme {
        View()

    }
}