package espasa.mario.scaffold_dialog_mario_espasa

import android.graphics.drawable.Icon
import android.os.Bundle
import android.util.Log
import android.widget.Space
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import espasa.mario.scaffold_dialog_mario_espasa.ui.theme.Scaffold_Dialog_Mario_EspasaTheme
import kotlinx.coroutines.launch

data class MyMessage(val title: String, val body: String)

private val messages: List<MyMessage> = listOf(
    MyMessage("James Richardson", "San Francisco"),
    MyMessage("Madeline Kennedy", "Fremont"),
    MyMessage("Anna Coleman", "San Francisco"),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Scaffold_Dialog_Mario_EspasaTheme {
                // A surface container using the 'background' color from the theme
                Surface(


                    modifier = Modifier
                        .fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    ViewContainer()
                }
            }
        }
    }
}

@Composable
fun ViewContainer(){

    val showDialog = rememberSaveable{ mutableStateOf(false) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            Column {
                MyImage()
                Button(
                    onClick = {}
                ) {
                    Text(text = "Education")
                }
                Button(
                    onClick = {}
                ) {
                    Text(text = "Experience")
                }
                Button(
                    onClick = {}
                ) {
                    Text(text = "Skills")
                }
            }
        },content = {
            Scaffold(
                topBar = { MyToolBar() },
                content = { Content() },
                bottomBar = { MyDownMenu() },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { showDialog.value = true }
                    ) {
                        androidx.compose.material.Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "añadir"
                        )
                    }
                }
            )
            if (showDialog.value)
                CustomDialog(value = "", setShowDialog = {
                    showDialog.value = it
                }) {
                    Log.i("HomePage", "HomePage : $it")
                }
        }
    )
}

@Composable
fun MyToolBar(){
    TopAppBar(
        title = { Text(text = "Alan Smith")}
    )


}


@Composable
fun MyDownMenu(){
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        BottomNavigation() {
            BottomNavigationItem(
                selected = false,
                onClick = { },
                icon = {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Home")
                }
            )
            BottomNavigationItem(
                selected = false,
                onClick = { },
                icon = {
                    Icon(imageVector = Icons.Default.Favorite, contentDescription = "favoritos")
                }
            )
            BottomNavigationItem(
                selected = false,
                onClick = { },
                icon = {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = "Location")
                }
            )
            BottomNavigationItem(
                selected = false,
                onClick = { },
                icon = {
                    Icon(imageVector = Icons.Default.Person, contentDescription = "cuenta")
                }
            )
        }
    }

}


@Composable
fun Content() {
    
    MySheets(messages)

}


//------------------------
//CREACION DE CELDAS
//------------------------





@Composable
fun MyImage(){
    Image(painter = painterResource(id = R.drawable.ic_launcher_foreground) , contentDescription = "logo", modifier = Modifier.size(64.dp))
}

@Composable
fun MyIcon(icono : ImageVector){
    androidx.compose.material.Icon(imageVector = icono, contentDescription = "Icono")
}


@Composable
fun MyTexts(message: MyMessage){
    var expanded by remember { mutableStateOf(false) }
    Column (modifier = Modifier.clickable {
        expanded = !expanded
    }){
        MyText(text = message.title, color = MaterialTheme.colors.primary)
        Spacer(modifier = Modifier.height(8.dp))
        Row() {
            MyIcon(icono = Icons.Default.LocationOn)
            MyText(
                text = message.body,
                color = MaterialTheme.colors.primary
            )
        }
    }
}

@Composable
fun MyText(text:String, color: Color){
    Text(text = text, color = color)
}

@Composable
fun MySheet(message: MyMessage){
    Row(modifier = Modifier.padding(8.dp)) {
        MyImage()
        MyTexts(message)
    }
    
}

@Composable
fun MySheets(messages:List<MyMessage>){

    LazyColumn(){
        items(messages){ message ->
            MySheet(message)
        }
    }
}