package espasa.mario.playingwithlayouts

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import espasa.mario.playingwithlayouts.ui.theme.PlayingWithLayoutsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PlayingWithLayoutsTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DefaultPreview()
                }
            }
        }
    }
}

@Composable
fun Back() {


    Box(){Column {
        Text(text = "Ejemplo 1",
            Modifier
                .background(Color.Cyan)
                .height(250.dp)
                .padding(top = 110.dp)
                .fillMaxWidth(),
            textAlign = TextAlign.Center)

        Row() {
            Text(text = "Ejemplo 2",
                Modifier
                    .background(Color.Red)
                    .height(250.dp)
                    .padding(top = 120.dp)
                    .width(200.dp),
                textAlign = TextAlign.Center)

            Text(text = "Ejemplo 3",
                Modifier
                    .background(Color.Green)
                    .height(250.dp)
                    .padding(top = 120.dp)
                    .width(200.dp),
                textAlign = TextAlign.Center)
        }

        Text(text = "Ejemplo 4", Modifier
            .background(Color.Magenta)
            .fillMaxWidth()
            .padding(top = 250.dp)
            .height(270.dp),
            textAlign = TextAlign.Center)

    }}



}


@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    PlayingWithLayoutsTheme {

        Back()

    }
}